<!-- footer-bottom -->
<div class="footer-bottom-area">
    <div class="container">
        <div class="footer-border">
            <div class="row d-flex justify-content-between align-items-center">
                <div class="col-xl-10 col-lg-9 ">
                    <div class="footer-copy-right">
                        <p>
                            Copyright &copy;
                            <script>
                                document.write(new Date().getFullYear());
                            </script> All rights reserved
                        </p>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3">
                    <div class="footer-social f-right">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</footer>
